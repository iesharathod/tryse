// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDGBY2-g_FEFlq6HqCzWel06upPe9U5McE",
    authDomain: "tryse-f24a6.firebaseapp.com",
    projectId: "tryse-f24a6",
    storageBucket: "tryse-f24a6.appspot.com",
    messagingSenderId: "32148259567",
    appId: "1:32148259567:web:42dc13e5890b95def4111a",
    measurementId: "G-5NQYXQ86HW"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);